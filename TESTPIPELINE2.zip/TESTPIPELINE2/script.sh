echo "Hello World"


echo " Please enter your choice ADD or SUB"

if [$s1 == "ADD"]
then
  echo "You are in add loop "
  Total =3+2
  echo ": $Total"
  
fi

echo " you are in sub loop"

Total = 3-2
echo ":$Total"

./nestedscript.sh  Saikrishna

exit
