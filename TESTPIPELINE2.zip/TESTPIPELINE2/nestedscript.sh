
name=$1
echo "calling Nested script inside script.sh"
echo " here am printing output from nested.sh file"

echo "Great work:$1"
exit

